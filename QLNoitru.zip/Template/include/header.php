<div>
      <div class="container-fluid">
        <div class="row nenxanh">
                <div class="col-md-4">
                    <img class="logo" src="images/logodhtn.png" alt="">
                </div>
                <div class="col-md-5     cantop"><center>
                        <h5 style="font-size: 1.75rem;"> TRANG NỘI TRÚ - ĐẠI HỌC CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG</h5>
                        </center>
                </div>
                <div class="col-md-3 cantop"><center>
                        <img class="logofb" src="images/logofb.png">
                </div>
        </div>
        <div class="row">
            <div class="col-12">
                <nav class="menu">
                    <ul>
                        <li><a  href="#">TRANG CHỦ</a></li>
                        <li><a  href="#">Webiste Trường</a></li>
                        <li><a  href="#">Trang sinh viên Trường</a></li>
                        <li><a href="#">Liên hệ</a></li>
                        <li><a class="ad" href="index.php?action=login">Đăng nhập</a></li>
                    </ul>
                </nav>
            </div>          
        </div>
    </div> 
</div>
 
