 <div class="container-fluid">
        <dir class="row">
            <div class="col-2 nenbac" style="margin-left: -20px">
                    <nav id="menu">      
                        <ul>
                            <h3> Sinh Viên </h3> 
                                    <li><a href="index.php?action=login">Đăng nhập</a></li>
                                    <li><a href="index.php?action=capnhapthongtin">Cập Nhập Thông Tin</a></li>
                                    <li><a href="index.php?action=dkphong">Đăng Ký Phòng</a></li>
                                    <li><a href="index.php?action=dangkychuyenphong">ĐK Chuyển Phòng</a></li>
                                    <li><a href="index.php?action=traphong">Trả Phòng</a></li>
                                    <li><a href="index.php?action=tracucphong">Tra cứu Phòng</a></li>
                                    <li><a href="index.php?action=phongdango">Xem Phòng Đang Ở</a></li>
                                    <li><a href="index.php?action=tracucphong">Thông báo sự cố</a></li>
                                    <li><a href="index.php?action=xemthongbao">Xem Thông Báo</a></li>
                                    <li><a href="index.php?action=logout">Đăng Xuất</a></li>
                        </ul>        
                      </nav>
            </div>
            <div class="col-8 ">
                <?php include_once('Template/include/content.php'); ?>
            </div>

        </dir>        
    </div>