  <script src="template/vendor/jquery/jquery.min.js"></script>
  <script src="template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="template/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="template/js/sb-admin-2.min.js"></script>
  <script src="template/vendor/chart.js/Chart.min.js"></script>
  <script src="template/js/demo/chart-area-demo.js"></script>
  <script src="template/js/demo/chart-pie-demo.js"></script>